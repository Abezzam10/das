from flask import Flask, render_template                #from flask imoirting render template
import sqlite3



'''DO NOT RUN THIS ON YOUR COMPUTER'''
import os                                               
os.chdir('/Users/Anirudh/Desktop/PYFILES')




app = Flask(__name__)

@app.route('/')             #'/' for each page
def welcome():
    return "Welcome to the Instructor webpage of my esteemly mundane designed Instructor webpage    In the extention that you see above please type in the words 'instructors_courses' to access the courses the instructors have taken"

@app.route('/student_courses')              
def student_courses():

    query = """select s.cwid, s.name, s.major, count(g.Course) as Completed_courses
               from HW11_students s join HW11_grades g on s.cwid=g.Student_CWID
               group by s.cwid, s.name, s.major"""
    
    DB_FILE = 'D:/Dass.db'

    db = sqlite3.connect(DB_FILE)
    results = db.execute(query)

    data = [{'cwid': cwid, 'name': name, 'major': major, 'complete': complete} for cwid, name, major, complete in results]
    db.close()
    
    return render_template('student_courses.html', title="Stevens Repository", table_title="Number of completed courses by student", students=data)

@app.route('/instructor_courses')
def instructor_courses():

    query = 'select a.Instructor_CWID, b.Name, b.Dept, a.Course, count(*) as Student_Count from HW11_grades a join HW11_instructors b on \
    a.Instructor_CWID = b.CWID group by a.Course order by a.Instructor_CWID ASC'    
    
    DB_FILE = 'D:/Dass.db'

    db = sqlite3.connect(DB_FILE)
    results = db.execute(query)

    data = [{'cwid': cwid, 'name': name, 'department': department, 'courses': courses, 'students': students} for cwid, name, department, courses, students in results]

    db.close()

    return render_template('instructor_courses.html', title="Stevens Repository", table_title="Number of students by course and instructor", instructors=data)

app.run(debug=True)